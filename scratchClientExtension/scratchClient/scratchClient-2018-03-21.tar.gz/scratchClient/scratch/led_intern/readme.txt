When using config_ikg_button_led_intern.xml, the s8-Button switches the direction.
