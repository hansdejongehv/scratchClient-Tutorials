#
# SPIManager delegates for SPI Implementations
#
#
