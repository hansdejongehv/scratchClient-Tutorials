sample application for a 2*3 scratch screen panel arrangement.

See http://heppg.de/ikg/wordpress/?p=608 for a description.
