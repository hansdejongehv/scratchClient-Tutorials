The file adafruit_neopixel.zip is a copy of work done by adafruit.com.
For the original, see adafruit website.
