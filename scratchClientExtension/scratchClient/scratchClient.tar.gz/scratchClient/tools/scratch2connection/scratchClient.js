//
// load extension from local extensions provider
//

ScratchExtensions.loadExternalJS( 'http://127.0.0.1:8080/scratchx/js/extension.js' );
